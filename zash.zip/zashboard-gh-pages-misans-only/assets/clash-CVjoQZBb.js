import{aL as s,aN as t,aO as o}from"./index-e5P8U_kr.js";const n=async()=>{s.value=(await t()).data},c=async a=>{await o(a),n()};export{n as fetchConfigs,c as updateConfigs};
