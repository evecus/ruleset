import{aD as e,aE as a}from"./index-Ckq5k73N.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
