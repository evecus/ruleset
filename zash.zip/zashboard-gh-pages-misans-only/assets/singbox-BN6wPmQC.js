import{aT as e,aU as a}from"./index-PZcs4CjL.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
