import{aP as e,aQ as a}from"./index-e5P8U_kr.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
