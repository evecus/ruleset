import{aT as e,aU as a}from"./index-7yv-IeoY.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
