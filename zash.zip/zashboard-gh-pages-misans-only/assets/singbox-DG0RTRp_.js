import{aN as e,aO as a}from"./index-Bgw7X7EG.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
