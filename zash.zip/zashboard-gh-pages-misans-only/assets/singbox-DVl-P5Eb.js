import{aN as e,aO as a}from"./index-BHRJihfy.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
