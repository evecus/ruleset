import{aN as e,aO as a}from"./index-DzEKBLDG.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
