import{aL as s,aN as t,aO as o}from"./index-Bk0BFBFn.js";const n=async()=>{s.value=(await t()).data},c=async a=>{await o(a),n()};export{n as fetchConfigs,c as updateConfigs};
