import{aP as e,aQ as a}from"./index-CzeG31aE.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
