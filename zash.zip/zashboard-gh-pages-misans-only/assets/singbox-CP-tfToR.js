import{aP as e,aQ as a}from"./index-Bk0BFBFn.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
