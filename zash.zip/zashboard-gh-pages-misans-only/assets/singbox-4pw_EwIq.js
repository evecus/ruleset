import{aN as e,aO as a}from"./index-WYRi4Vnk.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
