import{aO as e,aP as a}from"./index-CCMw78mQ.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
