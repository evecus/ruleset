import{az as s,aB as t,aC as o}from"./index-Ckq5k73N.js";const n=async()=>{s.value=(await t()).data},c=async a=>{await o(a),n()};export{n as fetchConfigs,c as updateConfigs};
