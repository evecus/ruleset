import{aT as e,aU as a}from"./index-CNgyhCKu.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
